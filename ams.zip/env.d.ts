namespace NodeJS {
    interface ProcessEnv {
      NNEXT_PUBLIC_CONTENTFUL_SPACE_ID: string;
      NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN: string;
      NEXT_PUBLIC_URL: string;
    }
  }
  