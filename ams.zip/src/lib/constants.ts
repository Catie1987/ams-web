export const EASE_IN_OUT_CUBIC = [0.87, 0, 0.13, 1];

export const BREAKPOINTS = {
  SM: 640,
  MD: 768,
  LG: 1280,
  XL: 2000,
};
